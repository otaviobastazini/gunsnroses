import xbmcaddon

MainBase = 'http://pastebin.com/raw/YXVdrkuW'
addon = xbmcaddon.Addon('plugin.video.GunsNRoses')